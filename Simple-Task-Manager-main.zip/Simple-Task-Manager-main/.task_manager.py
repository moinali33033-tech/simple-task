tasks = []
while True:
    print("\n===== TASK MANAGER =====")
    print("1. Add Task")
    print("2. View Tasks")
    print("3. Remove Task")
    print("4. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        task = input("Enter task name: ")
        priority = input("Enter priority (High/Medium/Low): ")
        task_info = {
            "task": task,
            "priority": priority
        }
        tasks.append(task_info)
        print("Task Added Successfully!")
    elif choice == "2":
        if len(tasks) == 0:
            print("No tasks available.")
        else:
            print("\nYour Tasks:")

            for i, task in enumerate(tasks, start=1):

                print(
                    f"{i}. {task['task']} - Priority: {task['priority']}"
                )
    elif choice == "3":
        remove_task = input("Enter task name to remove: ")
        found = False
        for task in tasks:
            if task["task"] == remove_task:

                tasks.remove(task)

                found = True

                print("Task Removed!")

                break

        if found == False:
            print("Task not found.")
    elif choice == "4":

        print("Thank You!")

        break

    else:
        print("Invalid Choice")